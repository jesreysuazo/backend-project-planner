package com.example.projectplanner.model;

public enum Role {
    USER, ADMIN
}